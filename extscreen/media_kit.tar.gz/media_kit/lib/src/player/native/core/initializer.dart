/// This file is a part of media_kit (https://github.com/media-kit/media-kit).
///
/// Copyright © 2021 & onwards, Hitesh Kumar Saini <saini123hitesh@gmail.com>.
/// All rights reserved.
/// Use of this source code is governed by MIT license that can be found in the LICENSE file.
import 'dart:async';
import 'dart:ffi';

import 'initializer_isolate.dart';
import 'initializer_native_event_loop.dart';

import 'package:media_kit/generated/libmpv/bindings.dart';

/// Creates & returns initialized [Pointer<mpv_handle>].
/// Pass [path] to libmpv dynamic library & [callback] to receive event callbacks as [Pointer<mpv_event>].
///
/// Optionally, [options] may be passed to set libmpv options before the initialization.
///
/// Platform specific threaded event loop is preferred over [Isolate] based event loop (automatic fallback).
/// See package:media_kit_native_event_loop for more details.
abstract class Initializer {
  /// ==== PiliPlus patch (2026-10-16) ====
  ///
  /// Lets the host app force the "one Isolate per mpv handle" event loop.
  ///
  /// Why: [InitializerNativeEventLoop] relies on libmedia_kit_native_event_loop.so,
  /// whose `MediaKitEventLoopHandlerInitialize(callback, port)` registers a
  /// **process-global** wakeup port, while media_kit calls it once per Dart isolate
  /// and therefore overwrites it. PiliPlus's "external display" feature spins up a
  /// second FlutterEngine (= a second Dart isolate) in the same process, so as soon
  /// as that engine initializes media_kit it steals the global port and the first
  /// engine stops receiving its own mpv events. Since `NativePlayer.command()` is
  /// `mpv_command_async` + awaiting `MPV_EVENT_COMMAND_REPLY` (see real.dart), every
  /// command on the main player then never completes: `stop()` hits its 2s timeout
  /// and the `mpv_terminate_destroy()` scheduled 5s later by
  /// `NativePlayer.dispose()` blocks forever -> main-thread ANR (black screen, no
  /// controls, phone dead until killed).
  ///
  /// The host only has to set this callback to return true inside the secondary
  /// isolate so it uses [InitializerIsolate] instead: one dedicated isolate per mpv
  /// handle polling `mpv_wait_event`, touching no process-global state at all.
  static bool Function()? preferIsolateEventLoop;

  static bool get _useIsolateEventLoop => preferIsolateEventLoop?.call() ?? false;

  /// Creates & returns initialized [Pointer<mpv_handle>].
  static FutureOr<Pointer<mpv_handle>> create(
    MPV mpv,
    FutureOr<void> Function(Pointer<mpv_event> event)? callback, {
    Map<String, String> options = const {},
  }) {
    if (_useIsolateEventLoop) {
      final r = InitializerIsolate.create(mpv, callback, options);
      return r;
    }
    try {
      final r = InitializerNativeEventLoop.create(mpv, callback, options);
      return r;
    } catch (e, s) {
      Zone.current.handleUncaughtError(e, s);
      return InitializerIsolate.create(mpv, callback, options);
    }
  }

  /// Disposes the event loop of the [Pointer<mpv_handle>] created by [create].
  /// NOTE: [Pointer<mpv_handle>] itself is not disposed.
  static void dispose(Pointer<mpv_handle> handle) {
    if (_useIsolateEventLoop) {
      InitializerIsolate.dispose(handle);
      return;
    }
    try {
      InitializerNativeEventLoop.dispose(handle);
    } catch (_) {
      InitializerIsolate.dispose(handle);
    }
  }
}
